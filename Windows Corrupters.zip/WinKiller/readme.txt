So this file is named as quiz to be less *SUS*


But so it works this way

You run the quiz.py file

It will run a script to make quiz.bat a user and admin

Then quiz.bat will delete specific files

It may not be enough to corrupt the OS

but may put in self recovery mode

We tested this on Windows 10 and it put's it into a self-recovery screen

on windows 8 we had the scripts run but the OS got corrupted in a loop and bsod

DO NOT RUN ON YOUR HOST

RUN ON RISK!!!!!!!!!!!!!!!
